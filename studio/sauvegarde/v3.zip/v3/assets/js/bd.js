const SERVICES = []

SERVICES["seco_securite"] = {
    title: "Seco Securite",
    description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!",
    cover: "../images/new/bg_seco_securite.jpg"
}

SERVICES["seco_tech"] = {
    title: "Seco Tech",
    description: `
    <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    cover: "../images/new/bg_seco_tech.jpg"
}

SERVICES["seco_distributors"] = {
    title: "Seco Distributors",
    description: `
     <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    cover: "../images/new/bg_seco_distributor.jpg"
}

SERVICES["seco_agro_industries"] = {
    title: "Seco Agro-Industries",
    description: `
     <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    cover: "../images/new/bg_seco_agro_industries.jpg"

}

SERVICES["seco_energy_co"] = {
    title: "Seco Energy CO",
    description: `
     <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,cover: "../images/new/bg_seco_energy_co.jpg"

}

SERVICES["seco_univers_construction"] = {
    title: "Seco Univers Constructions",
    description: ` <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,cover: "../images/new/bg_seco_univers_construction.jpg"

}

SERVICES["mass_assurances"] = {
    title: "Mass Assurances",
    description:` <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,
     cover: "../images/new/bg_mass_assurance.jpg"

}

SERVICES["mass_funds"] = {
    title: "Mass Funds",
    description:` <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,
    cover: "../images/new/bg_mass_funds.jpg"

}