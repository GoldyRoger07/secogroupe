    
    window.onload = ()=>{

        // await new Promise(resolve => setTimeout(resolve, 2000));
        document.querySelector("#content").style.display="block"
        document.querySelector(".loading-container").style.display="none"
        
    }