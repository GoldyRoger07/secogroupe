const SERVICES = []

SERVICES["seco_securite"] = {
    title: "Seco Securite",
    description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!",
    cover: "../images/new/bg_seco_securite.jpg"
}

SERVICES["seco_tech"] = {
    title: "Seco Tech",
    description: `
    <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    cover: "../images/new/bg_seco_tech.jpg"
}

SERVICES["seco_distributors"] = {
    title: "Seco Distributors",
    description: `
     <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    // cover: "../images/new/bg_seco_distributor.jpg"
    cover: "https://www.plugandtrack.com/wp-content/uploads/2022/05/Normes-stockage-distribution-medicaments-e1652099964737.jpg"
}

SERVICES["seco_agro_industries"] = {
    title: "Seco Agro-Industries",
    description: `
     <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `,
    // cover: "../images/new/bg_seco_agro_industries.jpg"
    cover: "https://plus.unsplash.com/premium_photo-1661962573121-d4c317caf908?q=80&w=1529&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"

}

SERVICES["seco_energy_co"] = {
    title: "Seco Energy CO",
    description: `
     <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>
    `//,cover: "../images/new/bg_seco_energy_co.jpg"
    ,cover: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"

}

SERVICES["seco_univers_construction"] = {
    title: "Seco Univers Constructions",
    description: ` <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,cover: "https://plus.unsplash.com/premium_photo-1661962573121-d4c317caf908?q=80&w=1529&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"

}

// ../images/new/bg_seco_univers_construction.jpg

SERVICES["mass_assurances"] = {
    title: "Mass Assurances",
    description:` <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,
     cover: "../images/new/bg_mass_assurance.jpg"
    // cover: "/home/sonix/Téléchargements/krakenimages-Y5bvRlcCx8k-unsplash.jpg"

}

SERVICES["mass_funds"] = {
    title: "Mass Funds",
    description:` <p style="color: #fff;">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum aperiam eius tempora, necessitatibus quod, inventore soluta voluptate rerum obcaecati esse corrupti! Voluptatum magni quis et magnam atque optio, quos esse!
    </p>`,
    cover: "../images/new/bg_mass_funds.jpg"

}